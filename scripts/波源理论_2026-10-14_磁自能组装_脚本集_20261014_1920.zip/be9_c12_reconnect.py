# -*- coding: utf-8 -*-
"""
Be-9 / C-12 磁重联推广（标准口径）
E_rec = τ_b · Σ_{i<j} (ΔB_eff)²/μ₀ · V_rec，V_rec=0.129fm³（decisions#11）
α 团簇：正四面体 4 核子 a=1.605fm（氦核 Σm=0 方案C 精确闭合 28.296），内部 Σm=0（α 磁矩 0 实验事实）
构型：Be-9=2α+n（α-α 距 R 实验 2.9-3.5fm）；C-12=3α 等边三角形（边长 R 实验 ~3.0-3.7fm）
真实：Be-9 58.165 MeV；C-12 92.162 MeV
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients):
    NG=len(centers); E=0.0; t=0.5
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
def alpha(c, a, ori):
    """α 正四面体 4 核子中心（p,p,n,n）"""
    a*=1e-15
    return [c+np.array([a/2,-sq3_6*a,-zc*a]), c+np.array([-a/2,-sq3_6*a,-zc*a]),
            c+np.array([0,sq3_3*a,-zc*a]), c+np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori
# Σm=0 方案（氦核审计 4 方案，方案C 闭合 1.605）
ALPHA_ORI=[
 [ [0,1,0],[0,1,0],[0,-1,0],[0,-1,0] ],
 [ [0,1,0],[0,-1,0],[0,-1,0],[0,1,0] ],
 [ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ],
 [ [0,1,0],[0,-1,0],[0,0,1],[0,0,-1] ],
]
a_he=1.605

# ① 自检：单 α 内部结合能（a=1.605, 方案C）
ac,ak,ao=alpha(np.zeros(3),a_he,ALPHA_ORI[2])
Ea=E_rec(ac,ak,ao)
print(f"① α 内部 a=1.605 方案C: {Ea:.3f} MeV vs 28.296 ({Ea/28.296:.4f}×)")

print("\n② Be-9 2α+n：扫 α-α 距 R 与 n 位置（真实 58.165，实验 R 2.9-3.5fm）")
print(f"{'R':>5}{'n位':>6}{'E_rec':>10}{'×58.17':>9}")
bestB=None
for R in np.arange(2.7,3.8,0.1):
    c1=np.array([-R/2,0,0])*1e-15; c2=np.array([R/2,0,0])*1e-15
    for npos in ["mid","perp1","perp2"]:
        if npos=="mid": nc=np.array([0,0,0])*1e-15
        elif npos=="perp1": nc=np.array([0,0.8,0])*1e-15
        else: nc=np.array([0,0,0.8])*1e-15
        centers=[]; kinds=[]; orients=[]
        for c in [c1,c2]:
            cc,kk,oo=alpha(c,a_he,ALPHA_ORI[2]); centers+=cc; kinds+=kk; orients+=oo
        centers.append(nc); kinds.append('n')
        for no in [[1,0,0],[0,1,0],[0,0,1],[0,-1,0],[0,0,-1]]:
            ori=orients+[no]
            E=E_rec(centers,kinds,ori)
            print(f"{R:5.1f}{npos:>6}{E:10.2f}{E/58.165:9.3f}")
            if bestB is None or abs(E-58.165)<abs(bestB[0]-58.165): bestB=(E,R,npos,no)

print("\n③ C-12 3α 等边三角形：扫边长 R（真实 92.162，实验 ~3.0-3.7fm）")
print(f"{'R':>5}{'E_rec':>10}{'×92.16':>9}")
bestC=None
for R in np.arange(2.8,3.8,0.1):
    c1=np.zeros(3); c2=np.array([R,0,0])*1e-15; c3=np.array([R/2,np.sqrt(3)*R/2,0])*1e-15
    centers=[]; kinds=[]; orients=[]
    for c in [c1,c2,c3]:
        cc,kk,oo=alpha(c,a_he,ALPHA_ORI[2]); centers+=cc; kinds+=kk; orients+=oo
    E=E_rec(centers,kinds,orients)
    print(f"{R:5.1f}{E:10.2f}{E/92.162:9.3f}")
    if bestC is None or abs(E-92.162)<abs(bestC[0]-92.162): bestC=(E,R)

print(f"\n最优 Be-9: R={bestB[1]}fm n位={bestB[2]} n向={bestB[3]} → {bestB[0]:.2f} MeV ({bestB[0]/58.165:.3f}×)")
print(f"最优 C-12: R={bestC[1]}fm → {bestC[0]:.2f} MeV ({bestC[0]/92.162:.3f}×)")
