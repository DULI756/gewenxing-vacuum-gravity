# -*- coding: utf-8 -*-
"""
双约束取向求解 · 爬山优化（无 scipy 版）
目标：E_pair = Σ_{i<j} U_ij ≈ 938.27 MeV 且 净矩 ≈ 2.79 μN
从径向取向（E=665、净矩=0）出发，扰动 10 源方向，加权目标爬山
f = -(E_pair/938-1)^2 - 50*(净矩/2.79-1)^2  （越大越好，两约束均衡）
多起点 + 随机重启，报告可达区域
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
rp=0.84e-15
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
m1=115.9*muN/10.0
def metrics(us):
    mus=m1*us
    E=0.0
    for i in range(10):
        for j in range(i+1,10):
            rv=J17[i]-J17[j]; r=np.linalg.norm(rv); rh=rv/r
            E+=(mu0/(4*np.pi*r**3))*(np.dot(mus[i],mus[j])-3*np.dot(mus[i],rh)*np.dot(mus[j],rh))
    return E/MeV, np.linalg.norm(mus.sum(axis=0))/muN
def rand_dir(rng):
    z=rng.uniform(-1,1); ph=rng.uniform(0,2*np.pi)
    s=np.sqrt(max(0,1-z*z))
    return np.array([s*np.cos(ph),s*np.sin(ph),z])
def perturb(u,rng,sig):
    z=rng.uniform(-sig,sig); ph=rng.uniform(0,2*np.pi)
    s=np.sqrt(max(0,1-z*z))
    v=np.array([s*np.cos(ph),s*np.sin(ph),z])
    w=u+v; n=np.linalg.norm(w)
    return w/n if n>1e-30 else u
rng=np.random.default_rng(2026)
best_glob=None; trail=[]
for restart in range(12):
    # 起点：径向 + 噪声
    us=np.array([r/np.linalg.norm(r)+0.15*rng.standard_normal(3) for r in J17])
    us=np.array([u/np.linalg.norm(u) for u in us])
    E,nm=metrics(us); f=-(E/938.272-1)**2-50*(nm/2.79-1)**2
    sig=0.6
    for step in range(6000):
        k=rng.integers(0,10)
        un=us.copy(); un[k]=perturb(us[k],rng,sig)
        En,nmn=metrics(un)
        fn=-(En/938.272-1)**2-50*(nmn/2.79-1)**2
        if fn>f or rng.random()<0.002:   # 贪心 + 少量随机
            us,E,nm,f=un,En,nmn,fn
            if step%500==0 and step>100: sig=max(0.08,sig*0.97)
    if best_glob is None or f>best_glob[0]:
        best_glob=(f,E,nm,us)
        trail.append((E,nm))
    print(f"重启{restart+1}: E_pair={E:.1f} MeV  净矩={nm:.3f} μN  (f={f:.4f})")
E,nm,us=best_glob[1],best_glob[2],best_glob[3]
print(f"\n最优: E_pair={E:.2f} MeV (目标938.27, {E/938.272:.3f}×)  净矩={nm:.3f} μN (目标2.79, {nm/2.79:.2f}×)")
print(f"可达区提示: 径向E=665(净矩0) → 最优f={best_glob[0]:.3f}")
print("判读: 若最优接近 (938, 2.79) → 双约束可同时满足; 若 E 远低于 938 → 源对互作用口径下两约束冲突")
