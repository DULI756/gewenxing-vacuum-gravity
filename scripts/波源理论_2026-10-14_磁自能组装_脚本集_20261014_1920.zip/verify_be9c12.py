# -*- coding: utf-8 -*-
"""
Be-9/C-12 计算过程验证（补审计）
1. α 内部闭合点复现对照（li6_reconnect_v4.py 同扫法：a 1.10-2.0 步0.005 找 E≤28.296 首点）
   → 验证 alpha() 构型与审计脚本一致
2. 贡献分解：C-12=3α内部+3α-α对；Be-9=2α内部+α-α对+α-n对
3. 敏感性：α 内 a 变化对闭合 R 的影响（a=1.55/1.60/1.605/1.65）
4. 数值核对：C-12 66对/Be-9 36对 vs N_pair 公式
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients,tau=True):
    NG=len(centers); E=0.0; t=0.5 if tau else 1.0
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E
def pair_E(ca,ka,oa,cb,kb,ob,tau=True):
    """单对核子组间磁重联贡献（可负？不，E_rec 恒正累加）"""
    mid=(ca+cb)/2.0
    gpa,gma=src(ca,ka,oa); Ba=B_field(mid[None,:],gpa,gma)[0]
    gpb,gmb=src(cb,kb,ob); Bb=B_field(mid[None,:],gpb,gmb)[0]
    dB=np.linalg.norm(Ba-Bb)/2.0
    return (0.5 if tau else 1.0)*dB*dB/mu0*Vrec/MeV
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
def alpha(c, a, ori):
    a*=1e-15
    return [c+np.array([a/2,-sq3_6*a,-zc*a]), c+np.array([-a/2,-sq3_6*a,-zc*a]),
            c+np.array([0,sq3_3*a,-zc*a]), c+np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori
ALPHA_ORI=[
 [ [0,1,0],[0,1,0],[0,-1,0],[0,-1,0] ],
 [ [0,1,0],[0,-1,0],[0,-1,0],[0,1,0] ],
 [ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ],
 [ [0,1,0],[0,-1,0],[0,0,1],[0,0,-1] ],
]
print("1️⃣ α 内部闭合点复现（对照 li6_reconnect_v4.py 同扫法）")
for ai,ori in enumerate(ALPHA_ORI,1):
    c=None
    for s in np.arange(1.10,2.00,0.005):
        a=s*1e-15
        centers=[np.array([a/2,-sq3_6*a,-zc*a]), np.array([-a/2,-sq3_6*a,-zc*a]),
                 np.array([0,sq3_3*a,-zc*a]), np.array([0,0,sq6_4*a])]
        if E_rec(centers,['p','p','n','n'],ori)<=28.296:
            c=s; break
    print(f"  方案{ai} 闭合 s={c} fm  {'✅ 与审计锚一致' if c and abs(c-[1.558,1.604,1.604,1.615][ai-1])<0.02 else '⚠️ 偏移'}")
print(f"  方案C(a=1.605) E={E_rec(alpha(np.zeros(3),1.605,ALPHA_ORI[2])[0],['p','p','n','n'],ALPHA_ORI[2]):.3f} vs 28.296")

print("\n2️⃣ 贡献分解（a=1.605 方案C, τ_b=0.5）")
# C-12 R=3.55（闭合区间中点）
R=3.55; c1=np.zeros(3); c2=np.array([R,0,0])*1e-15; c3=np.array([R/2,np.sqrt(3)*R/2,0])*1e-15
acs=[alpha(c,1.605,ALPHA_ORI[2]) for c in [c1,c2,c3]]
E_in=sum(E_rec(a[0],a[1],a[2]) for a in acs)
E_aa=0
for i in range(3):
    for j in range(i+1,3):
        # αi 4核子 vs αj 4核子：16 对核子对，逐对
        e=0
        for x in range(4):
            for y in range(4):
                e+=pair_E(acs[i][0][x],acs[i][1][x],acs[i][2][x],acs[j][0][y],acs[j][1][y],acs[j][2][y])
        E_aa+=e
print(f"  C-12 R=3.55: α内部 {E_in:.2f} + α-α对(48核子对) {E_aa:.2f} = 总 {E_in+E_aa:.2f} vs 92.162 ({ (E_in+E_aa)/92.162:.3f}×)")
# 对级分解（用组级 E_rec 交叉验证：组间 = E_rec(9核子,全组)-组内）
allc=[]; allk=[]; allo=[]
for a in acs: allc+=a[0]; allk+=a[1]; allo+=a[2]
E_all=E_rec(allc,allk,allo)
print(f"  交叉验证（组级算法）: 总 {E_all:.2f} vs 逐对 {E_in+E_aa:.2f} 差 {abs(E_all-(E_in+E_aa)):.3f} MeV")
print(f"  α-α对/对 = {E_aa/3:.2f} MeV（16 核子对）")

# Be-9 R=4.0（闭合点）n z=3.0
R2=4.0; d1=np.array([-R2/2,0,0])*1e-15; d2=np.array([R2/2,0,0])*1e-15; nc=np.array([0,0,3.0])*1e-15
bcs=[alpha(d1,1.605,ALPHA_ORI[2]),alpha(d2,1.605,ALPHA_ORI[2])]
E_inb=sum(E_rec(b[0],b[1],b[2]) for b in bcs)
e_aan=0
for b in bcs:
    for x in range(4):
        e_aan+=pair_E(b[0][x],b[1][x],b[2][x],nc,'n',[1,0,0])
e_aa2=0
for x in range(4):
    for y in range(4):
        e_aa2+=pair_E(bcs[0][0][x],bcs[0][1][x],bcs[0][2][x],bcs[1][0][y],bcs[1][1][y],bcs[1][2][y])
print(f"  Be-9 R=4.0 h=3.0: α内部 {E_inb:.2f} + α-α对 {e_aa2:.2f} + α-n对(8) {e_aan:.2f} = 总 {E_inb+e_aa2+e_aan:.2f} vs 58.165 ({ (E_inb+e_aa2+e_aan)/58.165:.3f}×)")
allc=[]; allk=[]; allo=[]
for b in bcs: allc+=b[0]; allk+=b[1]; allo+=b[2]
allc.append(nc); allk.append('n'); allo.append([1,0,0])
print(f"  交叉验证（组级算法）: 总 {E_rec(allc,allk,allo):.2f} vs 逐对 {E_inb+e_aa2+e_aan:.2f}")

print("\n3️⃣ 敏感性：α 内 a 对闭合 R 的影响")
for a_ in [1.55,1.60,1.65,1.70]:
    # C-12 找闭合 R
    rc=None
    for R in np.arange(3.0,4.3,0.1):
        c1=np.zeros(3); c2=np.array([R,0,0])*1e-15; c3=np.array([R/2,np.sqrt(3)*R/2,0])*1e-15
        centers=[]; kinds=[]; orients=[]
        for c in [c1,c2,c3]:
            cc,kk,oo=alpha(c,a_,ALPHA_ORI[2]); centers+=cc; kinds+=kk; orients+=oo
        E=E_rec(centers,kinds,orients)
        if E<=92.162: rc=R; break
    print(f"  α内a={a_}: C-12 闭合 R≈{rc} fm {'✅ 落区间' if rc and 3.0<=rc<=3.7 else '⚠️ 偏移'}")

print("\n4️⃣ N_pair 核对")
for Z,A in [(4,9),(6,12)]:
    Np=(Z*(Z-1)//2)+((A-Z)*(A-Z-1)//2)+Z*(A-Z)
    print(f"  {Z}Be{A if Z==4 else 12}: N_pair={Np}（总核子对数 {A*(A-1)//2}）")
print("  C-12 计算对=66（脚本组级遍历 C(12,2)）；Be-9 计算对=36（组级 C(9,2)）")
