# -*- coding: utf-8 -*-
"""Be-9 敏感性：α 内边长 a 对闭合 α-α 距 R 的影响（验证步骤 3 补充）
发现：C-12 闭合 R 对 a 敏感（a:1.60→R3.7, 1.65→3.3, 1.70→3.2）；Be-9 若同向敏感，a 增大可把 R≈4.0 拉回实验区间
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients,tau=True):
    NG=len(centers); E=0.0; t=0.5 if tau else 1.0
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
def alpha(c, a, ori):
    a*=1e-15
    return [c+np.array([a/2,-sq3_6*a,-zc*a]), c+np.array([-a/2,-sq3_6*a,-zc*a]),
            c+np.array([0,sq3_3*a,-zc*a]), c+np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori
ORI_C=[ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ]
print("Be-9 闭合 R × α内a 敏感性（n z=3.0；真实 58.165，实验 α-α 距 2.9-3.5）")
for a_ in [1.55,1.60,1.605,1.65,1.70,1.75]:
    best=(None,1e9)
    for R in np.arange(2.7,4.6,0.05):
        c1=np.array([-R/2,0,0])*1e-15; c2=np.array([R/2,0,0])*1e-15; nc=np.array([0,0,3.0])*1e-15
        centers=[]; kinds=[]; orients=[]
        for c in [c1,c2]:
            cc,kk,oo=alpha(c,a_,ORI_C); centers+=cc; kinds+=kk; orients+=oo
        centers.append(nc); kinds.append('n'); orients.append([1,0,0])
        E=E_rec(centers,kinds,orients)
        if abs(E-58.165)<best[1]: best=(R,abs(E-58.165))
    print(f"  α内a={a_}: 最接近58.165的 R={best[0]:.2f} (ΔE={best[1]:.2f}MeV) {'✅ 落区间' if best[0] and 2.9<=best[0]<=3.5 else '⚠️ 偏移'}")