# -*- coding: utf-8 -*-
"""
双约束取向求解：质子 10 源 J17 几何
约束1：源对偶极互作用能 E_pair = Σ_{i<j} U_ij = 938.27 MeV（波源『多源干涉场能』口径）
约束2：净偶极矩 |Σμ_k| = 2.79 μN（实验质子磁矩，用户猜想：115.9=内部强度、2.79=净矩）
扫描『锥面取向族』：u_k = cosθ·a + sinθ·b_k（a=主轴，b_k=绕a均匀方位）
θ=0 → 全同向（净矩最大）；θ=90° → 赤道平面均匀（净矩≈0）
净矩约束 |Σu|=2.79/115.9*10=0.2408 → cosθ=0.02408 → θ≈88.62°
检查该 θ 下 E_pair 是否 ≈938（两约束是否可同时满足）
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
rp=0.84e-15
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
m1=115.9*muN/10.0   # 单源 11.59 μN
def U_pair(pos,mus):
    """偶极-偶极互作用能总和（解析，SI→MeV）"""
    E=0.0
    for i in range(len(pos)):
        for j in range(i+1,len(pos)):
            rv=pos[i]-pos[j]; r=np.linalg.norm(rv)
            rh=rv/r
            U=(mu0/(4*np.pi*r**3))*(np.dot(mus[i],mus[j])-3*np.dot(mus[i],rh)*np.dot(mus[j],rh))
            E+=U
    return E/MeV
def cone(theta_deg,axis=np.array([0,1,0])):
    axis=axis/np.linalg.norm(axis); base=np.array([1,0,0])
    e1=np.cross(axis,base); e1/=np.linalg.norm(e1); e2=np.cross(axis,e1)
    th=np.radians(theta_deg); phis=np.linspace(0,2*np.pi,10,endpoint=False)
    us=[]
    for ph in phis:
        us.append(np.cos(th)*axis+np.sin(th)*(np.cos(ph)*e1+np.sin(ph)*e2))
    return np.array(us)
def radial_orients():
    return np.array([r/np.linalg.norm(r) for r in J17])
print("质子 10 源双约束求解（J17 几何，单源 11.59μN）")
print(f"目标：E_pair=938.27MeV 且 净矩=2.79μN（|Σu|=0.2408）\n")
print(f"{'θ(°)':>7}{'|Σu|':>8}{'净矩μN':>10}{'E_pair MeV':>14}{'E/938':>8}{'净矩/2.79':>10}")
for th in [0,10,20,30,40,50,60,70,80,85,88,88.62,89,90]:
    u=cone(th); mus=m1*u
    nm=np.linalg.norm(mus.sum(axis=0))/muN
    Ep=U_pair(J17,mus)
    print(f"{th:>7.2f}{np.linalg.norm(u.sum(axis=0)):>8.3f}{nm:>10.3f}{Ep:>14.3f}{Ep/938.272:>8.3f}{nm/2.79:>10.2f}")
print("\n径向对称（净矩=0 参考）：")
u=radial_orients(); mus=m1*u
print(f"  净矩={np.linalg.norm(mus.sum(axis=0))/muN:.4f} μN, E_pair={U_pair(J17,mus):.3f} MeV")
print("\n判读：若 θ=88.62°（净矩=2.79）处 E_pair≈938 → 双约束可同时满足（猜想数值成立）")
print("若 E_pair(θ=88.62°) 远离 938 → 平面均匀族不满足，需更一般球面分布搜索")
