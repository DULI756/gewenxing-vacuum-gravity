# -*- coding: utf-8 -*-
"""叠加场能基线：10 源同向，扫描受阻截断 r_cut 与积分上限（broadcasting 版）"""
import numpy as np, sys, traceback
try:
    mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
    rp=0.84e-15
    R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
    J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
     (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
     (0,0,axH),(0,0,-axH)],float)*rp
    m1=115.9*muN/10.0
    def E_super(us, r_cut, R_max, Nr=36, Nth=18, Nph=36):
        mus=m1*us
        rs=np.linspace(r_cut, R_max, Nr)
        ths=np.linspace(0,np.pi,Nth); phs=np.linspace(0,2*np.pi,Nph,endpoint=False)
        R,TH,PH=np.meshgrid(rs,ths,phs,indexing='ij')
        R=R.ravel(); TH=TH.ravel(); PH=PH.ravel()
        X=R*np.sin(TH)*np.cos(PH); Y=R*np.sin(TH)*np.sin(PH); Z=R*np.cos(TH)
        P=np.vstack([X,Y,Z]).T
        keep=np.ones(len(P),bool)
        for s in J17:
            keep &= (np.linalg.norm(P-s,axis=1)>r_cut)
        P=P[keep]; R=R[keep]; TH=TH[keep]
        B=np.zeros((len(P),3))
        for k in range(10):
            rv=P-J17[k]; r=np.maximum(np.linalg.norm(rv,axis=1),1e-30)
            rh=rv/r[:,None]; mvec=mus[k][None,:]
            md=np.einsum('ij,ij->i',rh,np.broadcast_to(mvec,(len(P),3)))
            Bk=(mu0/(4*np.pi*r[:,None]**3))*(3*md[:,None]*rh-np.broadcast_to(mvec,(len(P),3)))
            B+=Bk
        u=(np.linalg.norm(B,axis=1)**2)/(2*mu0)
        dV=R*np.sin(TH)*(rs[1]-rs[0])*(ths[1]-ths[0])*(phs[1]-phs[0])
        return np.sum(u*dV)/MeV, len(P)
    U=np.tile([0,1,0],(10,1))
    print("叠加场能基线：10 源同向（净矩=115.9μN）")
    print(f"{'r_cut(fm)':>10}{'R=0.84 核内 MeV':>18}{'R=0.935 d MeV':>18}{'E/938':>10}")
    for rc in [0.05,0.08,0.10,0.12,0.15,0.20,0.25,0.30]:
        e1,_=E_super(U,rc*rp,0.84e-15); e2,_=E_super(U,rc*rp,0.9348e-15)
        print(f"{rc:>10.2f}{e1:>18.2e}{e2:>18.2e}{e2/938.272:>10.2e}")
except Exception:
    traceback.print_exc()
