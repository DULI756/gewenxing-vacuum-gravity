# -*- coding: utf-8 -*-
"""
磁重联湮灭热辐射强度计算（标准口径，meetings#32）
物理：磁重联湮灭释放磁能 E_rec → 在重联区 V_rec 内沉积热化 → 等效黑体辐射
口径：能量密度 u=E/V → 黑体温度 T=(u/a)^(1/4) → 维恩峰值波长 → Stefan-Boltzmann 功率
对照标准核物理：氘核结合能 2.2246 MeV = n+p→d+γ 单伽马光子（核物理标准事实）
"""
import numpy as np, math
a=7.5657e-16   # 辐射常数 J/(m³·K⁴)
sig=5.6704e-8  # Stefan-Boltzmann W/(m²·K⁴)
bW=2.8978e-3   # 维恩位移 m·K
c=2.9979e8; h=6.626e-34; kB=1.38065e-23
MeV=1.602176634e-13
Vrec=0.129e-45 # m³（标准口径每对）

def rad(label, E_MeV, V_m3, n_pairs=1, desc=""):
    E=E_MeV*MeV
    u=E/V_m3
    T=(u/a)**0.25
    lam=bW/T
    r_eff=(3*V_m3/(4*np.pi))**(1/3)
    A=4*np.pi*r_eff**2
    P=sig*T**4*A
    tau=r_eff/c
    E_ph_gamma=E/(1.602176634e-13) if False else E/MeV  # 单光子上限 MeV
    nu=E/h
    kT=kB*T/MeV
    print(f"── {label} {desc}")
    print(f"  释放能量 E={E_MeV:.3f} MeV ({E:.3e} J)")
    print(f"  重联体积 V={V_m3/1e-45:.3f} fm³  能量密度 u={u:.2e} J/m³")
    print(f"  等效黑体温度 T={T:.2e} K")
    print(f"  维恩峰值波长 λ_max={lam:.2e} m（{lam*1e10:.2f} Å，伽马/X 波段）")
    print(f"  热光子典型能量 k_B T={kT:.2f} MeV")
    print(f"  单光子上限 hν=E={E_ph_gamma:.3f} MeV（ν={nu:.2e} Hz）")
    print(f"  辐射面积 A={A:.2e} m²（r_eff={r_eff/1e-15:.3f} fm）")
    print(f"  峰值辐射功率 P=σT⁴A={P:.2e} W")
    print(f"  辐射时间尺度 τ=r_eff/c={tau:.2e} s  总辐射能量 P·τ={P*tau/MeV:.3f} MeV（自洽≈E? {'✓' if abs(P*tau-E)/E<1 else '✗ 需复核'}）")

print("=== 磁重联湮灭热辐射（标准口径 V_rec=0.129fm³/对）===")
rad("氘核", 2.2246, Vrec, 1, "(1 对反平行，sep=1.989fm)")
rad("氦核/对", 28.296/4, Vrec, 4, "(Σm=0 4 对反平行，每对 7.074 MeV)")
rad("氦核总和", 28.296, 4*Vrec, 4, "(4 对总能量/总体积口径)")
rad("Li-6/对", 31.995/15, Vrec, 15, "(15 对均分 2.133 MeV/对，示意)")
rad("Li-6 总和", 31.995, 15*Vrec, 15, "(15 对总能量/总体积)")

print("\n=== 标准核物理对照 ===")
print("n+p→d+γ：结合能 2.2246 MeV 以单伽马光子释放（ν=5.38e20 Hz，λ=5.6e-13 m）——核物理标准事实")
print("氦核 α 结合能 28.296 MeV（4He），Li-6 31.995 MeV")
print("\n=== 量级判断 ===")
print("T~1e12 K 远高于恒星核(~1e7-1e8 K)：fm³ 内沉积 MeV 级能量的必然结果（能量密度 e33-e34 J/m³）")
print("辐射波段=伽马（λ~1e-15 m）；峰值功率 e11-e12 W 持续 e-24 s——瞬时强伽马闪，非稳态热源")
