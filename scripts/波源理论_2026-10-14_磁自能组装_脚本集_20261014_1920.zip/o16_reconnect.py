# -*- coding: utf-8 -*-
"""
O-16 磁重联推广（第7锚，裁决性）：4α 正四面体
真实：BE=127.619MeV（KAERI/IAEA）；实验 α-α 边长 3.42fm（EQMD 模型，rms 2.699 与实验一致）
检验：α 内边长 a 用 Be-9/C-12 双闭合窗口（1.64-1.65）→ O-16 闭合 R 是否≈3.42 且落实验区间
N_pair=C(8,2)+C(8,2)+64=120 对
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients):
    NG=len(centers); E=0.0; t=0.5
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E
def pair_E(ca,ka,oa,cb,kb,ob):
    mid=(ca+cb)/2.0
    gpa,gma=src(ca,ka,oa); Ba=B_field(mid[None,:],gpa,gma)[0]
    gpb,gmb=src(cb,kb,ob); Bb=B_field(mid[None,:],gpb,gmb)[0]
    dB=np.linalg.norm(Ba-Bb)/2.0
    return 0.5*dB*dB/mu0*Vrec/MeV
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
def alpha(c, a, ori):
    a*=1e-15
    return [c+np.array([a/2,-sq3_6*a,-zc*a]), c+np.array([-a/2,-sq3_6*a,-zc*a]),
            c+np.array([0,sq3_3*a,-zc*a]), c+np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori
ORI_C=[ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ]
# 4α 正四面体顶点（边长 R）
TET=np.array([(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)],float)
print(f"0️⃣ N_pair 核对: C(8,2)+C(8,2)+64={28+28+64}（总核子对 C(16,2)=120）")
print("\n1️⃣ 扫 R（α-α 边长）× a：真实 127.619，实验 R=3.42fm")
for a_ in [1.605,1.64,1.65,1.70]:
    best=(None,1e9); hits=[]
    for R in np.arange(2.7,3.9,0.02):
        cs=[TET[i]*R/(2*np.sqrt(2))*1e-15 for i in range(4)]
        centers=[]; kinds=[]; orients=[]
        for c in cs:
            cc,kk,oo=alpha(c,a_,ORI_C); centers+=cc; kinds+=kk; orients+=oo
        E=E_rec(centers,kinds,orients)
        if abs(E-127.619)<best[1]: best=(R,abs(E-127.619))
        if abs(E-127.619)<1.0: hits.append((R,E))
    tag="✅" if best[0] and abs(best[0]-3.42)<0.3 else ""
    print(f"  a={a_:.3f}: 最接近闭合 R={best[0]:.2f}fm (ΔE={best[1]:.2f}MeV, {127.619/best[1]:.1f}??) {tag}")
    if hits: print(f"    ΔE<1MeV 窗口: {['R=%.2f→%.2f'%(h[0],h[1]) for h in hits]}")
print("\n2️⃣ 贡献分解验证（a=1.65, R=3.42 实验值）")
R=3.42; cs=[TET[i]*R/(2*np.sqrt(2))*1e-15 for i in range(4)]
acs=[alpha(c,1.65,ORI_C) for c in cs]
E_in=sum(E_rec(a[0],a[1],a[2]) for a in acs)
E_aa=0
for i in range(4):
    for j in range(i+1,4):
        for x in range(4):
            for y in range(4):
                E_aa+=pair_E(acs[i][0][x],acs[i][1][x],acs[i][2][x],acs[j][0][y],acs[j][1][y],acs[j][2][y])
allc=[]; allk=[]; allo=[]
for a in acs: allc+=a[0]; allk+=a[1]; allo+=a[2]
E_all=E_rec(allc,allk,allo)
print(f"  α内部 4×{E_in/4:.2f}={E_in:.2f} + α-α对(96核子对) {E_aa:.2f} = {E_in+E_aa:.2f} vs 组级 {E_all:.2f}（差 {abs(E_all-E_in-E_aa):.3f} MeV）vs 127.619（{E_all/127.619:.3f}×）")
print(f"  α-α对/对 = {E_aa/6:.2f} MeV（16 核子对/团簇对）")
