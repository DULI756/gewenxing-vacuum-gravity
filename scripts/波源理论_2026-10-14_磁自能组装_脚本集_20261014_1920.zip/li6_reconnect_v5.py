# -*- coding: utf-8 -*-
"""Li-6 磁重联·标准口径（meetings#32）：E=τ_b·Σ(ΔB)²/μ₀·V_rec，V_rec=0.129"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients,tau=True):
    NG=len(centers); E=0.0; t=0.5 if tau else 1.0
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
ALPHA_ORI=[
 [ [0,1,0],[0,1,0],[0,-1,0],[0,-1,0] ],
 [ [0,1,0],[0,-1,0],[0,-1,0],[0,1,0] ],
 [ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ],
 [ [0,1,0],[0,-1,0],[0,0,1],[0,0,-1] ],
]
sep_d=1.989e-15; D_AXES=[[1,0,0],[0,1,0],[0,0,1]]
print("Li-6 磁重联标准口径（V_rec=0.129, ×τ_b）α+d Σm=0 12组合扫 D")
print(f"{'α':<3}{'d轴':<4}{'D=2.5':>9}{'2.8':>8}{'3.0':>8}{'3.2':>8}{'3.4':>8}{'3.6':>8}{'4.0':>8}{'4.5':>8}")
best=None
for ai,alpha_ori in enumerate(ALPHA_ORI,1):
    for dax in D_AXES:
        row=[f"{ai}", f"{'xyz'[D_AXES.index(dax)]}"]
        for D in [2.5,2.8,3.0,3.2,3.4,3.6,4.0,4.5]:
            a=1.7e-15
            centers=[np.array([a/2,-sq3_6*a,-zc*a]), np.array([-a/2,-sq3_6*a,-zc*a]),
                     np.array([0,sq3_3*a,-zc*a]), np.array([0,0,sq6_4*a])]
            dc=np.array([D,0,0])*1e-15
            centers += [dc-np.array([sep_d/2,0,0]), dc+np.array([sep_d/2,0,0])]
            E=E_rec(centers,['p','p','n','n','p','n'],alpha_ori+[dax, [-x for x in dax]])
            row.append(f"{E:8.2f}")
            if best is None or abs(E-31.995)<abs(best[0]-31.995): best=(E,ai,D,dax)
        print("  ".join(row))
print(f"\n最优: α方案{best[1]} d轴{'xyz'[D_AXES.index(best[3])]} D={best[2]}fm → {best[0]:.2f} MeV ({best[0]/31.995:.3f}×)")
