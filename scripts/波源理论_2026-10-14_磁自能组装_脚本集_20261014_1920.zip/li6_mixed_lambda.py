# -*- coding: utf-8 -*-
"""
Li-6 混合 Λ 检验（中间态假说判决测试）
假说：氘核 p-n 相干锁定→能量层持续爆发→τ_b_eff=1.0（Λ=0.129）；α 团簇 Σm=0 间歇层保留→Λ=0.0645
检验：Li-6=α+d 用混合 Λ（α内 6对 0.0645、d内 1对 0.129、α-d 8对 两种取法）扫 D，
      看闭合 D 是否落实验区间 2.9-3.4
构型：α 方案1(p:+y p:+y n:−y n:−y) a=1.7 + d轴x(p:+x n:−x) sep=1.989（v5 最优组合）
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec_mixed(centers,kinds,orients,groups,Lambda):
    """按对级 Λ 表计算：Lambda[(gi,gj)]=乘积 τ_b·V_rec (m³)"""
    NG=len(centers); E=0.0
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            lam=Lambda[(min(groups[i],groups[j]),max(groups[i],groups[j]))]
            E+=lam*dB*dB/mu0/MeV
    return E
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
ORI_A1=[ [0,1,0],[0,1,0],[0,-1,0],[0,-1,0] ]
DAX=[1,0,0]; sep_d=1.989e-15
L_std=0.0645e-45; L_dd=0.129e-45
scenarios={
 "①现行(全0.0645)": {(0,0):L_std,(1,1):L_std,(0,1):L_std},
 "②混合-保守(α-d=0.0645)": {(0,0):L_std,(1,1):L_dd,(0,1):L_std},
 "③混合-全激活(α-d=0.129)": {(0,0):L_std,(1,1):L_dd,(0,1):L_dd},
}
print("Li-6 α+d 混合 Λ 检验：扫 D（实验区间 2.9-3.4，真实 31.995MeV）")
print(f"{'情形':<22}{'D=2.6':>9}{'2.9':>8}{'3.2':>8}{'3.4':>8}{'3.6':>8}{'3.9':>8}{'4.2':>8}{'4.5':>8}  闭合D")
for name,lam in scenarios.items():
    best=None; row=[]
    for D in [2.6,2.9,3.2,3.4,3.6,3.9,4.2,4.5]:
        a=1.7e-15
        centers=[np.array([a/2,-sq3_6*a,-zc*a]), np.array([-a/2,-sq3_6*a,-zc*a]),
                 np.array([0,sq3_3*a,-zc*a]), np.array([0,0,sq6_4*a])]
        dc=np.array([D,0,0])*1e-15
        centers += [dc-np.array([sep_d/2,0,0]), dc+np.array([sep_d/2,0,0])]
        groups=[0,0,0,0,1,1]
        E=E_rec_mixed(centers,['p','p','n','n','p','n'],ORI_A1+[DAX,[-x for x in DAX]],groups,lam)
        row.append(f"{E:8.2f}")
        if best is None or abs(E-31.995)<abs(best[0]-31.995): best=(E,D)
    tag="✅落区间" if best[1] and 2.9<=best[1]<=3.4 else "❌偏移"
    print(f"{name:<22}{'  '.join(row)}  {best[1]:.1f}({best[0]/31.995:.3f}×) {tag}")
print("\n判读：②③闭合 D 若落 2.9-3.4 → 混合 Λ（中间态假说）获支持；若超 3.4 → 假说被削弱")
