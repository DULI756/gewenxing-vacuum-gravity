# -*- coding: utf-8 -*-
"""
V_rec 几何化全候选扫描：4 种几何定义 × 三核锚
定义A: 间隙薄层圆柱（厚=sep−2rp、半径 r_gap=0.806·gap 审计口径）
定义B: 两核子 rp=0.84 球重叠体积
定义C: ΔB² 全空间积分（去芯）
定义D: ΔB² 薄层/重叠域积分（无自由参数，域=间隙圆柱或重叠区）
目标：氘核 2.2246 @sep=1.989；氦核 Σm=0 闭合 s∈1.4-1.7；Li-6 α+d 31.995
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; tau=0.5

def B_dip(P,pos,mvec):
    rv=P-pos; r=np.maximum(np.linalg.norm(rv,axis=1),1e-30); rh=rv/r[:,None]
    md=rh@mvec
    return (mu0/(4*np.pi*r[:,None]**3))*(3*md[:,None]*rh-mvec[None,:])

def gap_volume(sep):
    """A: 间隙薄层圆柱，厚=sep−2rp，半径 r_gap=0.806·gap（审计 0.249/0.309=0.806）"""
    gap=sep-2*rp
    if gap<=0: return 0.0, 0.0
    r_g=0.806*gap; return np.pi*r_g**2*gap, 0.0

def overlap_volume(sep,R):
    """B: 两球(R)重叠体积"""
    if sep>=2*R: return 0.0
    return np.pi/12*(4*R+sep)*(2*R-sep)**2

print("=== 定义A: 间隙薄层圆柱（审计几何）===")
for lab,sep in [("氘核",1.989e-15)]:
    V,_=gap_volume(sep); print(f"  {lab} sep={sep/1e-15:.3f}fm: V={V/1e-45:.4f}fm³ vs 审计薄层0.0601/标定0.0645")

print("\n=== 定义B: rp 球重叠体积 ===")
for lab,sep in [("氘核",1.989e-15),("氦核",1.558e-15)]:
    V=overlap_volume(sep,rp); print(f"  {lab}: V={V/1e-45:.4f}fm³ {'(无间隙)' if V<=0 else ''}")

print("\n=== 定义D: 薄层/重叠域 ΔB² 积分（氘核）===")
centers=[np.zeros(3),np.array([1.989e-15,0,0])]
# 域=间隙圆柱：|x−0.9945|<0.1545, sqrt(y²+z²)<0.249
xs=np.arange(-2,4.0,0.05)*1e-15; ys=np.arange(-1,1.01,0.05)*1e-15; zs=np.arange(-1,1.01,0.05)*1e-15
g=np.meshgrid(xs,ys,zs,indexing='ij'); P=np.stack([x.ravel() for x in g],axis=1)
mid=1.989e-15/2
mask=((np.abs(P[:,0]-mid)<0.1545e-15)&(np.sqrt(P[:,1]**2+P[:,2]**2)<0.249e-15))
Pm=P[mask]
Bi=B_dip(Pm,centers[0],np.array([0,1,0])*mup); Bj=B_dip(Pm,centers[1],np.array([0,-1,0])*mup)
dB2=np.sum((Bi-Bj)**2,axis=1)
E=0.5/mu0*np.sum(dB2)*(0.05e-15)**3/MeV
print(f"  间隙圆柱域 ΔB²积分: {E:.3f} MeV vs 2.2246 ({E/2.2246:.2f}×) | ×τ_b→{E*tau:.3f} | 域体积={len(Pm)*(0.05e-15)**3/1e-45:.4f}fm³")

print("\n=== 定义D: 重叠域 ΔB² 积分（氦核对 s=1.558, pn 反平行）===")
s=1.558e-15
# 简化：两点在 x 轴相距 s（几何示意），域=两 rp 球重叠区
c1=np.array([-s/2,0,0]); c2=np.array([s/2,0,0])
g2=np.meshgrid(np.arange(-1.3,1.31,0.04)*1e-15,np.arange(-0.6,0.61,0.04)*1e-15,np.arange(-0.6,0.61,0.04)*1e-15,indexing='ij')
P2=np.stack([x.ravel() for x in g2],axis=1)
ov=(np.linalg.norm(P2-c1,axis=1)<rp)&(np.linalg.norm(P2-c2,axis=1)<rp)
P2m=P2[ov]
Bi=B_dip(P2m,c1,np.array([0,1,0])*mup); Bj=B_dip(P2m,c2,np.array([0,-1,0])*mup)
dB2=np.sum((Bi-Bj)**2,axis=1)
E2=0.5/mu0*np.sum(dB2)*(0.04e-15)**3/MeV
print(f"  重叠域 ΔB²积分: {E2:.3f} MeV | ×τ_b→{E2*tau:.3f} | 域体积={len(P2m)*(0.04e-15)**3/1e-45:.4f}fm³ (解析重叠体积={overlap_volume(s,rp)/1e-45:.4f}fm³)")
print(f"  需 28.3/4对=7.08MeV/对（无τ_b）或 14.15（×τ_b）→ 差 {E2/7.08:.1f}×")
