# -*- coding: utf-8 -*-
"""
磁重联口径校准矩阵：4变体（源展开×τ_b）× 双锚（氘核2.2246 / 氦核Σm=0闭合1.558-1.615）
选出匹配变体 → 用同一实现算 Li-6 α+d Σm=0
ΔB_eff=|B_i−B_j|/2（i,j 中点矢量差模），V_rec=0.0645fm³/对
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; Vrec=0.0645e-45
rp=0.84e-15
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])

def src(center,kind,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    if kind=='p': return center+J17, np.tile((mup/10)*u,(10,1))
    return center+J17n, np.tile((mup/11)*u,(11,1))

def B_field(P, pos, m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]              # (S,N,3)
    r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)  # (S,N)
    rh=rv/r[:,:,None]
    md=np.einsum('ijk,ik->ij',rh,m)           # (S,N)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)                     # (N,3)

def E_rec(centers, kinds, orients, expand=True, tau=False):
    NG=len(centers); E=0.0; t=0.5 if tau else 1.0
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            if expand:
                gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
                gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            else:
                Bi=B_field(mid[None,:],centers[i],np.array(orients[i])*mup)[0]
                Bj=B_field(mid[None,:],centers[j],np.array(orients[j])*mup)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*2*dB*dB/mu0*Vrec/MeV
    return E

sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
ALPHA_ORI=[
 [ [0,1,0],[0,1,0],[0,-1,0],[0,-1,0] ],
 [ [0,1,0],[0,-1,0],[0,-1,0],[0,1,0] ],
 [ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ],
 [ [0,1,0],[0,-1,0],[0,0,1],[0,0,-1] ],
]
def he4(s, ori):
    a=s*1e-15
    return [np.array([a/2,-sq3_6*a,-zc*a]), np.array([-a/2,-sq3_6*a,-zc*a]),
            np.array([0,sq3_3*a,-zc*a]), np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori

print("磁重联校准矩阵（氘核锚 2.2246 @sep=1.989；氦核锚 Σm=0 闭合 s=1.558/1.604/1.604/1.615）")
for expand in [True, False]:
    for tau in [False, True]:
        lab=f"{'42源' if expand else '单偶极'} {'×τ_b' if tau else '无τ_b'}"
        Ed=E_rec([np.zeros(3), np.array([1.989e-15,0,0])], ['p','n'], [[0,1,0],[0,-1,0]], expand, tau)
        cl=[]
        for ori in ALPHA_ORI:
            c=None
            for s in np.arange(1.30,1.95,0.005):
                if E_rec(*he4(s,ori), expand, tau)<=28.296:
                    c=s; break
            cl.append(f"{c:.3f}" if c else ">1.95")
        print(f"{lab:>14}: 氘核={Ed:.3f} ({Ed/2.2246:.3f}×) | 氦核Σm=0闭合s={cl}")
