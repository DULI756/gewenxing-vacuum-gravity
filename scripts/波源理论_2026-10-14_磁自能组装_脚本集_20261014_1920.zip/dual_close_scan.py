# -*- coding: utf-8 -*-
"""双闭合精扫：α 内边长 a ∈ 1.60-1.75，找 Be-9 与 C-12 同时闭合且 α-α 距落实验区间（2.9-3.5）的窗口"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients):
    NG=len(centers); E=0.0; t=0.5
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
def alpha(c, a, ori):
    a*=1e-15
    return [c+np.array([a/2,-sq3_6*a,-zc*a]), c+np.array([-a/2,-sq3_6*a,-zc*a]),
            c+np.array([0,sq3_3*a,-zc*a]), c+np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori
ORI_C=[ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ]
print("双闭合扫描：a 1.60-1.75 × R 2.7-3.8（Be-9 n z=3.0；C-12 等边三角形）")
print(f"{'a':>5}{'Be9闭R':>8}{'ΔE':>7}{'C12闭R':>8}{'ΔE':>7}  双闭合窗口")
for a_ in np.arange(1.60,1.761,0.01):
    best9=(None,1e9); bestC=(None,1e9)
    for R in np.arange(2.7,3.9,0.02):
        # Be-9
        c1=np.array([-R/2,0,0])*1e-15; c2=np.array([R/2,0,0])*1e-15; nc=np.array([0,0,3.0])*1e-15
        centers=[]; kinds=[]; orients=[]
        for c in [c1,c2]:
            cc,kk,oo=alpha(c,a_,ORI_C); centers+=cc; kinds+=kk; orients+=oo
        centers.append(nc); kinds.append('n'); orients.append([1,0,0])
        E9=E_rec(centers,kinds,orients)
        if abs(E9-58.165)<best9[1]: best9=(R,abs(E9-58.165))
        # C-12
        c1=np.zeros(3); c2=np.array([R,0,0])*1e-15; c3=np.array([R/2,np.sqrt(3)*R/2,0])*1e-15
        centers=[]; kinds=[]; orients=[]
        for c in [c1,c2,c3]:
            cc,kk,oo=alpha(c,a_,ORI_C); centers+=cc; kinds+=kk; orients+=oo
        EC=E_rec(centers,kinds,orients)
        if abs(EC-92.162)<bestC[1]: bestC=(R,abs(EC-92.162))
    win9 = best9[0] and 2.9<=best9[0]<=3.5 and best9[1]<1.0
    winC = bestC[0] and 2.9<=bestC[0]<=3.5 and bestC[1]<1.0
    tag = "✅双闭合" if win9 and winC else ("9仅" if win9 else "")+("C仅" if winC else "")
    print(f"{a_:5.2f}{best9[0] or 0:8.2f}{best9[1]:7.2f}{bestC[0] or 0:8.2f}{bestC[1]:7.2f}  {tag}")
