# -*- coding: utf-8 -*-
"""
质子 10 源净偶极矩检验（源磁矩 115.9μN = 内部集体强度？净矩 = 实验 2.79μN？）
2026-10-14 用户猜想：115.9μN 是核子内部集体场效应峰值（禁闭内），主流 2.79μN 是远场净偶极矩
检验：J17 10 源几何下不同取向的净矩 |Σμ_k| vs 实验质子磁矩 2.79μN
"""
import numpy as np
muN=5.050783699e-27; rp=0.84e-15
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
m=115.9*muN; mu1=m/10.0
def net(uvecs):  # uvecs: (10,3) 单位方向
    return np.linalg.norm((mu1*uvecs).sum(axis=0))/muN
# 方案A：全部同向（基线，定义即 115.9）
A=np.tile([0,1,0],(10,1))
# 方案B：每源沿自身径向（J17 几何对称）
B=np.array([r/np.linalg.norm(r) for r in J17])
# 方案C：10源16面体展宽收口近似（2026-10-08 记录 |Σm|/N=0.8404 → 净≈0.8404*115.9）
rng=np.random.default_rng(7)
C=[]
for _ in range(10):
    # 锥形展布：绕 y 轴 σ≈51°（0.84 收口系数对应平均夹角 ≈ arccos(0.8404)≈32.8°? 用记录值反推平均角）
    pass
# 直接构造满足 |Σu|=0.8404*10 的锥分布：10 方向绕 y 轴均匀方位 + 固定锥角 θ，调整 θ 使 |Σu|=8.404
def cone_sum(theta_deg, n=10, axis=np.array([0,1,0])):
    axis=axis/np.linalg.norm(axis); base=np.array([1,0,0])
    e1=np.cross(axis,base); e1/=np.linalg.norm(e1); e2=np.cross(axis,e1)
    th=np.radians(theta_deg); phis=np.linspace(0,2*np.pi,n,endpoint=False)
    us=[]
    for ph in phis:
        us.append(np.cos(th)*axis+np.sin(th)*(np.cos(ph)*e1+np.sin(ph)*e2))
    return np.array(us)
lo,hi=1.0,90.0
for _ in range(80):
    mid=(lo+hi)/2
    if (np.linalg.norm(cone_sum(mid).sum(axis=0))-0.8404*10)<0: hi=mid
    else: lo=mid
theta=(lo+hi)/2; C=cone_sum(theta)
print("质子 10 源净偶极矩检验（单源=115.9/10=11.59μN）")
print(f"{'取向方案':<32}{'净矩 |Σμ| (μN)':>18}{'vs 实验 2.79':>16}")
for name,uv in [("A 全部同向（定义基线）",A),("B 每源沿 J17 径向（对称）",B),("C 展宽收口(记录|Σm|/N=0.8404)",C)]:
    nm=net(uv); print(f"{name:<32}{nm:>18.3f}{nm/2.79:>14.3f}×")
print(f"\n展宽锥角 θ={theta:.1f}°（对应收口系数 0.8404）")
print(f"→ 若要净矩=实验 2.79μN：需 |Σu_vec|/10 = 2.79/115.9 = {2.79/115.9:.4f}")
print(f"  即 10 源矢量和模 = {2.79/115.9*10:.3f}（抵消 97.6%），当前展宽收口模型为 {0.8404*10:.3f}（仅抵消 16%）")
print("\n判读：当前 10 源取向模型净矩 ~97μN ≫ 2.79μN → 若猜想成立（115.9=内部强度、2.79=净矩），")
print("需要『净矩约束』的取向重排：源方向近乎完全抵消(97.6%)而磁自能仍 938——两约束是否可同时满足，是猜想的数值判决点")
