# -*- coding: utf-8 -*-
"""
Be-9 磁重联重扫：n 为弱束缚价中子（分离能 1.665MeV），远离 α 核
构型：2α 正四面体（a=1.605, Σm=0 方案C）+ n 在 α-α 垂直方向高度 h / 外延
真实 58.165 MeV；实验 α-α 距 2.9-3.5fm；n-α 距（JINR 回旋镖 1.9fm / 分子 n-CM 4.65fm）
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15; Vrec=0.129e-45
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients):
    NG=len(centers); E=0.0; t=0.5; pairs={}
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            e=t*dB*dB/mu0*Vrec/MeV
            E+=e
    return E
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
def alpha(c, a, ori):
    a*=1e-15
    return [c+np.array([a/2,-sq3_6*a,-zc*a]), c+np.array([-a/2,-sq3_6*a,-zc*a]),
            c+np.array([0,sq3_3*a,-zc*a]), c+np.array([0,0,sq6_4*a])], ['p','p','n','n'], ori
ORI_C=[ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ]
a_he=1.605
print("Be-9 重扫：n 垂直高度 h（α-α 连线中垂线）与 x 外延，扫 R×h×n向")
print(f"{'R':>4}{'h位':>6}{'n向':>4}{'E_rec':>9}{'×58.17':>8}")
best=None
for R in [3.7,3.9,4.1,4.3,4.5]:
    c1=np.array([-R/2,0,0])*1e-15; c2=np.array([R/2,0,0])*1e-15
    for h in [3.0,3.5,4.0,4.5,5.0]:
        nc=np.array([0,0,h])*1e-15; tag="z"
        centers=[]; kinds=[]; orients=[]
        for c in [c1,c2]:
            cc,kk,oo=alpha(c,a_he,ORI_C); centers+=cc; kinds+=kk; orients+=oo
        centers.append(nc); kinds.append('n'); orients.append([1,0,0])
        E=E_rec(centers,kinds,orients)
        print(f"{R:4.1f}{tag}{h:.1f}{'x':>5}{E:9.2f}{E/58.165:8.3f}")
        if best is None or abs(E-58.165)<abs(best[0]-58.165): best=(E,R,h,0)
print(f"\n最优 Be-9: R={best[1]}fm h位={best[2]} → {best[0]:.2f} MeV ({best[0]/58.165:.3f}×)")
