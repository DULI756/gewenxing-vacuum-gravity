# -*- coding: utf-8 -*-
"""
Li-6 磁重联·标准口径重算（meetings#32 拍板：去 2 因子）
E_rec = τ_b · Σ_{i<j} (ΔB_eff)²/μ₀ · V_rec   （标准双场湮灭，无 2 因子）
V_rec,std = E_d·μ₀/ΔB_d² = 0.129 fm³（氘核标准标定，ΔB=5.89e13）
校验：氘核 sep=1.989 无τ_b → 2.2246；氦核 42源 Σm=0 闭合点重扫；Li-6 α+d 扫 D
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15
Vrec=0.129e-45  # fm³→m³（标准口径标定）
R0,hh,axH=0.4238,0.2520,0.6758; sq=np.sqrt(2)
J17=np.array([(R0,0,-hh),(0,R0,-hh),(-R0,0,-hh),(0,-R0,-hh),
 (R0/sq,R0/sq,hh),(-R0/sq,R0/sq,hh),(-R0/sq,-R0/sq,hh),(R0/sq,-R0/sq,hh),
 (0,0,axH),(0,0,-axH)],float)*rp
J17n=np.vstack([J17,np.zeros((1,3))])
def src(c,k,o):
    u=np.asarray(o,float); u=u/np.linalg.norm(u)
    return (c+J17, np.tile((mup/10)*u,(10,1))) if k=='p' else (c+J17n, np.tile((mup/11)*u,(11,1)))
def B_field(P,pos,m):
    pos=np.atleast_2d(pos); m=np.atleast_2d(m)
    rv=P[None,:,:]-pos[:,None,:]; r=np.maximum(np.linalg.norm(rv,axis=2),1e-30)
    rh=rv/r[:,:,None]; md=np.einsum('ijk,ik->ij',rh,m)
    Bk=(mu0/(4*np.pi*r[:,:,None]**3))*(3*md[:,:,None]*rh-m[:,None,:])
    return Bk.sum(axis=0)
def E_rec(centers,kinds,orients,tau=True):
    NG=len(centers); E=0.0; t=0.5 if tau else 1.0
    for i in range(NG):
        for j in range(i+1,NG):
            mid=(centers[i]+centers[j])/2.0
            gpi,gmi=src(centers[i],kinds[i],orients[i]); Bi=B_field(mid[None,:],gpi,gmi)[0]
            gpj,gmj=src(centers[j],kinds[j],orients[j]); Bj=B_field(mid[None,:],gpj,gmj)[0]
            dB=np.linalg.norm(Bi-Bj)/2.0
            E+=t*dB*dB/mu0*Vrec/MeV
    return E

# ① 氘核校验（无τ_b，标准口径）
Ed=E_rec([np.zeros(3), np.array([1.989e-15,0,0])], ['p','n'], [[0,1,0],[0,-1,0]], tau=False)
print(f"① 氘核标准口径 V_rec=0.129 无τ_b: {Ed:.4f} MeV vs 2.2246 ({Ed/2.2246:.4f}×)")
print(f"   42源(单偶极对照：单偶极ΔB=5.94e13→V=0.127)")

# ② 氦核 42源 Σm=0 4方案扫 s（标准口径，τ_b 两变体）
sq3_6=np.sqrt(3)/6; sq3_3=np.sqrt(3)/3; zc=1/(2*np.sqrt(6)); sq6_4=np.sqrt(6)/4
ALPHA_ORI=[
 [ [0,1,0],[0,1,0],[0,-1,0],[0,-1,0] ],
 [ [0,1,0],[0,-1,0],[0,-1,0],[0,1,0] ],
 [ [1,0,0],[-1,0,0],[-1,0,0],[1,0,0] ],
 [ [0,1,0],[0,-1,0],[0,0,1],[0,0,-1] ],
]
print("\n② 氦核标准口径 Σm=0 4方案闭合点（锚: 落 1.4-1.7）")
for ai,ori in enumerate(ALPHA_ORI,1):
    for lab,tau in [("无τ_b",False),("×τ_b",True)]:
        c=None
        for s in np.arange(1.10,2.00,0.005):
            a=s*1e-15
            centers=[np.array([a/2,-sq3_6*a,-zc*a]), np.array([-a/2,-sq3_6*a,-zc*a]),
                     np.array([0,sq3_3*a,-zc*a]), np.array([0,0,sq6_4*a])]
            if E_rec(centers,['p','p','n','n'],ori,tau)<=28.296:
                c=s; break
        print(f"  方案{ai} {lab}: 闭合 s={c if c else '>2.0'}fm {'✅' if c and 1.4<=c<=1.7 else ''}")
