# -*- coding: utf-8 -*-
"""
V_rec 几何化·第一性方案：磁重联 ΔB² 场直接积分（取代 V_rec 常数）
E_rec,ij = (1/2μ₀) ∫ |B_i−B_j|² dV  （去芯 rp=0.84，两核子中心球内剔除）
单偶极（对齐审计 #1028 ΔB=5.89e13）→ 42源对照
锚：氘核 sep=1.989→2.2246；氦核 Σm=0 闭合 s 落 1.4-1.7；Li-6 α+d 31.995
"""
import numpy as np
mu0=1.25663706212e-6; muN=5.050783699e-27; MeV=1.602176634e-13
mup=115.9*muN; rp=0.84e-15
tau_b=0.5

def B_dip_field(P, pos, mvec):
    rv=P-pos; r=np.maximum(np.linalg.norm(rv,axis=1),1e-30); rh=rv/r[:,None]
    md=rh@mvec
    return (mu0/(4*np.pi*r[:,None]**3))*(3*md[:,None]*rh-mvec[None,:])

def B_group(P, centers, orients, expand=True):
    """P(N,3) 处叠加场"""
    B=np.zeros((len(P),3))
    for c,o in zip(centers,orients):
        if expand:
            # 简化：单偶极占位（42源对照另行实现）
            B+=B_dip_field(P,c,np.array(o)*mup)
    return B

def E_rec_integral(centers, orients, expand=True, grid_res=0.1, half=3.0):
    """ΔB²场积分：每对 (1/2μ0)∫|B_i−B_j|²dV 去芯"""
    NG=len(centers); E=0.0; per=[]
    # 统一网格（包围所有核子）
    mn=np.min(centers,axis=0)-half*1e-15; mx=np.max(centers,axis=0)+half*1e-15
    g=np.meshgrid(*[np.arange(mn[k],mx[k]+1e-30,grid_res*1e-15) for k in range(3)],indexing='ij')
    P=np.stack([x.ravel() for x in g],axis=1)
    # 去芯掩码：每核子中心 0.84fm 球内剔除
    core=np.zeros(len(P),bool)
    for c in centers:
        core |= (np.linalg.norm(P-c,axis=1)<rp)
    P=P[~core]
    for i in range(NG):
        for j in range(i+1,NG):
            Bi=B_group(P,[centers[i]],orients[i],expand)
            Bj=B_group(P,[centers[j]],orients[j],expand)
            dB2=np.sum((Bi-Bj)**2,axis=1)
            e=0.5/mu0*np.sum(dB2)*(grid_res*1e-15)**3/MeV
            E+=e; per.append((round(np.linalg.norm(centers[i]-centers[j])/1e-15,3),e))
    return E,per

# ① 氘核 sep=1.989 反平行（单偶极）
centers=[np.zeros(3), np.array([1.989e-15,0,0])]
orients=[[0,1,0],[0,-1,0]]
E,per=E_rec_integral(centers,orients,expand=False)
print(f"① 氘核 ΔB²积分(单偶极,无τ_b): {E:.4f} MeV vs 2.2246 ({E/2.2246:.3f}×) | ×τ_b→{E*tau_b:.4f}")
print(f"   对 {per[0][0]}fm → {per[0][1]:.4f} MeV")
