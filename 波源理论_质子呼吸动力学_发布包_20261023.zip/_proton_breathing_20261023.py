# -*- coding: utf-8 -*-
"""
质子呼吸模拟 2026-10-23 v2（修正傅里叶基波计算 + 明确模型口径）
公设（用户指定）：f0 = 1.606e23 Hz，τ_b=τ_i=0.5，10 波源同频
→ 质子球直径随相位扩展/收缩（呼吸）
"""
import sys, math
sys.stdout.reconfigure(encoding='utf-8')
import sympy as sp

h    = 6.62607015e-34
c    = 2.99792458e8
f0   = 1.606e23
tau_b= 0.5
T    = 1/f0
d    = c/(2*f0)          # 半周期光速推进距离 = c·(τ_b·T)
fm   = 1e-15
MeV  = 1e6*1.602176634e-19

print("="*78)
print("0. 公设参数（f0=1.606e23 Hz 口径）")
print("="*78)
print(f"  f0 = {f0:.4e} Hz；T = {T:.4e} s；τ_b=τ_i=0.5")
print(f"  d = c·(τ_b·T) = c/(2f0) = {d/fm:.6f} fm（能量层半周期内光速推进距离 = 天然振幅）")
print(f"  对照：库内定稿 f0=1.60353e23 → d=0.934789 fm（差 {(d-0.934789e-15)/(0.934789e-15)*100:+.2f}%）")
print()

print("="*78)
print("1. 符号模型：三角波呼吸 R(t) = r_c + d·tri(t/T)")
print("="*78)
x = sp.symbols('x', real=True)
tri = sp.Piecewise((2*x, x < sp.Rational(1,2)), (2-2*x, True))
# 傅里叶系数（周期1）：a_n=2∫tri·cos(2πnx)dx, b_n=2∫tri·sin(2πnx)dx
a1 = 2*sp.integrate(tri*sp.cos(2*sp.pi*x), (x, 0, 1))
b1 = 2*sp.integrate(tri*sp.sin(2*sp.pi*x), (x, 0, 1))
print(f"  a1 = 2∫tri·cos(2πx)dx = {sp.simplify(a1)} ≈ {float(a1):.4f}")
print(f"  b1 = 2∫tri·sin(2πx)dx = {sp.simplify(b1)} ≈ {float(b1):.4f}")
A1 = sp.sqrt(a1**2 + b1**2)
print(f"  基波振幅 |c1| = sqrt(a1²+b1²) = {float(A1):.4f}（三角波峰值1的基波振幅 = 4/π²）")
print(f"  → 主频分量 = 基频 f0（cos 项），呼吸频率 = f0 ✓（b1=0 是偶函数必然，非无主频）")
print(f"  半径基波振幅 = d·A1 = {float(d/fm*A1):.4f} fm；直径基波振幅 = {float(2*d/fm*A1):.4f} fm")
print()

print("="*78)
print("2. 两种模型口径（必须明确选择）")
print("="*78)
print("  口径A（本模拟）：波源自质子中心爆发，半周期光速推进 d")
print(f"    → 包络半径 R∈[r_core, r_core+d] = [0.8407, {0.84075+d/fm:.4f}] fm，振幅 = d = {d/fm:.4f} fm")
print("  口径B（A-V 模型）：场区在 [r_p, d] 内呼吸（库内 A-V 两层：核心 0.84 ↔ 1/e 边界 0.935）")
print(f"    → 振幅 = (d-r_p)/2 = {(d/fm-0.84075)/2:.4f} fm")
print("  用户主张'波源爆发推进'→ 口径A；用户此前主张'核心在 r_p↔d 震荡'→ 口径B")
print("  两者物理含义不同，本模拟以口径A为主（本轮公设：爆发半周期推进 = 天然振幅 d）")
print()

print("="*78)
print("3. 数值模拟（口径A）：10 源同频同相 → 质子球呼吸")
print("="*78)
r_core = 0.84075  # fm, CODATA 2022
nt = 10000
Ts = 5*T
dt_ = Ts/nt
def tri_phase(ph):
    return 2*ph if ph < 0.5 else 2-2*ph
R = [r_core + (d/fm)*tri_phase((tt/T) % 1.0) for tt in [i*dt_ for i in range(nt)]]
R_min, R_max = min(R), max(R)
R_avg = sum(R)/nt
amp = (R_max-R_min)/2
v_exp = d/(tau_b*T)      # 上升段位移 = d（米），耗时 = τ_b·T
print(f"  呼吸范围 R∈[{R_min:.4f}, {R_max:.4f}] fm")
print(f"  半径峰值振幅 = d/2 = {amp:.4f} fm（{amp/r_core*100:.1f}% of core）；直径振幅 = d = {2*amp:.4f} fm")
print(f"  时间平均 = {R_avg:.4f} fm（vs core 0.84075：{(R_avg-r_core)/r_core*100:+.2f}%）")
print(f"  呼吸频率 = f0 = {f0:.3e} Hz；呼吸能量 = h·f0 = {h*f0/MeV:.2f} MeV")
print(f"  膨胀速度 = 上升位移d/τ_b·T = {v_exp:.3e} m/s = {v_exp/c:.4f}·c（=c 是 d 定义的自洽结果 ✓）")
print()

print("="*78)
print("4. 与主流测量精度对照（诚实标注）")
print("="*78)
prec = 0.00064
print(f"  测量精度 ±{prec} fm（CODATA 2022，±{prec/r_core*100:.3f}%）")
print(f"  [口径A] 若呼吸的是电荷分布：振幅 {amp:.4f} fm = 精度 {amp/prec:.0f} 倍；")
print(f"    时间平均 {R_avg:.4f} vs 实测 0.84075 偏差 {(R_avg-r_core)/r_core*100:.1f}%（{abs(R_avg-r_core)/prec:.0f}×精度）→ 早已被实验排除 ✗")
print(f"  [口径A] 波源理论口径：呼吸的是场区/几何包络，电荷测量只探测内层核心（不动）→ 不可直接测 ✓")
print(f"  [口径B] 若核心在 r_p↔d 呼吸：振幅 {(d/fm-0.84075)/2:.4f} fm = {((d/fm-0.84075)/2)/prec:.0f}×精度 → 同样被排除 ✗（_check_pulse_amplitude 已证）")
print()

print("="*78)
print("5. f0 口径敏感性")
print("="*78)
for fv in [1.60353e23, 1.606e23, 1.60648e23]:
    dv = c/(2*fv)
    print(f"  f0={fv:.6e} → d={dv/fm:.6f} fm, 呼吸能量 h·f0={h*fv/MeV:.2f} MeV, 包络振幅={dv/fm:.4f} fm")
print("  结论：两口径定性不变（呼吸能量差 0.14%）")
