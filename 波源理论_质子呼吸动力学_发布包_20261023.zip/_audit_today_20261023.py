# -*- coding: utf-8 -*-
"""今日(2026-10-23)工作独立复核：不依赖今日脚本，纯 math 重算关键数值"""
import sys, math
sys.stdout.reconfigure(encoding='utf-8')

h    = 6.62607015e-34
c    = 2.99792458e8
f0   = 1.60353e23
d    = c/(2*f0)
mpc2 = 938.272046
MeV  = 1e6*1.602176634e-19
fm   = 1e-15

print("="*70)
print("① 层谱关键半径（独立重算）")
print("="*70)
print(f"d = c/2f0 = {d/fm:.6f} fm")
print(f"ωr/c=1 → r = c/2πf0 = {c/(2*math.pi*f0)/fm:.6f} fm")
print(f"E_self=m_e 交叉: r = r_p·(m_p/m_e)^(1/3) = 0.84×{(1.67262192369e-27/9.1093837015e-31)**(1/3):.6f} = {0.84e-15*(1.67262192369e-27/9.1093837015e-31)**(1/3)/fm:.4f} fm")
print(f"场衰减e^-11位置: x+ln(x)=11 → x≈8.8227 → r = {8.8227*d/fm:.4f} fm")
print(f"Schwinger临界: d·ln(E_p/E_S), E_p=1542×E_S → r = {d*math.log(1542)/fm:.4f} fm = {math.log(1542):.4f}·d")

print()
print("="*70)
print("② 恒等式检验：ωr/c=π 是否 ≡ d")
print("="*70)
print(f"πc/ω = πc/2πf0 = c/2f0 = d → 恒等式成立 ✓（同义反复，非独立交叉）")

print()
print("="*70)
print("③ Roper 反推（独立重算）")
print("="*70)
f_b = (1430-mpc2)*MeV/h
f2d = 2*f0/math.e
f34 = 0.75*f0
print(f"f_breath(m=1430) = {f_b:.4e} Hz")
print(f"2·f(d) = {f2d:.4e} Hz, 比值 = {f_b/f2d:.4f}")
print(f"(3/4)·f0 = {f34:.4e} Hz, 比值 = {f_b/f34:.4f}")
print(f"2/e = {2/math.e:.4f}, 3/4 = 0.75 → 差 {abs(2/math.e-0.75)/0.75*100:.2f}%")
fb_pole = (1330-mpc2)*MeV/h
print(f"pole口径(m≈1330): f_b={fb_pole:.4e}, vs 2f(d) 偏差 {(fb_pole/f2d-1)*100:+.1f}%")

print()
print("="*70)
print("④ 今日结论存活状态清单（基于对话记录）")
print("="*70)
print("""[已确认有效]
  - 层谱半径排序：0.298 < 0.84 < 0.935 < 6.86 < 8.22~8.25 < 10.29 fm（算术正确）
  - ωr/c=π≡d 是恒等式（无独立内容）
  - 场衰减e^-11 位置 = 8.82d（非11d）——昨日算术错误已纠正
  - 2/e ≈ 3/4（差1.9%）→ '唯一命中'表述过度
  - MC：随机候选命中Roper区间概率 57.5% → 统计显著性低
  - pole口径下两个候选脱靶 ~20%
  - 质子呼吸↔Roper 判别实验方向有效（待第一性公式）

[已撤回/降级]
  - '重合① d双重身份'（恒等式过度解读）→ 撤回
  - '重合② 11d三重边界'（算术错误）→ 撤回
  - 'Roper数据唯一选出2·f(d)'（多重比较）→ 降级为'等价候选'

[未落库（重大缺口）]
  - 今日全部工作：层谱/审计/呼吸/反推/再审计 → 研究库 research_log 无记录
  - 会议库最新 #58（2026-10-20），无今日会议
  - results 最新 #22（双锚合一），无今日条目
  - 今日脚本 _proton_layers/_audit_layers/_roper_breathing/_roper_inversion/_audit_roper
    在当前环境不可见（2026-10-22 目录不存在）""")
