# -*- coding: utf-8 -*-
"""
质子呼吸动力学 v3 2026-10-23：质量涌现框架（用户指正，与公理M一致）
用户修正：m 是磁自能场耦合的效果——单波源基本无质量；
  两源以上靠近→质量涌现；波源分开→质量衰减到 0。
模型更新：
  ① 质量涌现 m(x) = E_coup(x)/c²  （公理M：质量=场耦合效应）
  ② 恢复力同源：k(x) = d²E_coup/dx² （场能决定刚度，非独立参数）
  ③ 平衡间距 a≈0.42fm（meetings#56 耦合峰值）
  ④ E_coup(x) 取波源场衰减形式（指数，特征尺度 d）
结论对比旧版（m 固定均分）的差异，并审计 m→0 极限
"""
import sys, math
sys.stdout.reconfigure(encoding='utf-8')
import sympy as sp

h     = 6.62607015e-34
c     = 2.99792458e8
f0    = 1.606e23
tau_b = 0.5
T     = 1/f0
d_m   = c/(2*f0)          # m，场衰减特征尺度 0.9334e-15
fm    = 1e-15
MeV   = 1e6*1.602176634e-19

print("="*78)
print("0. 公设链（全部库内 confirmed）")
print("="*78)
print("""
  - 质量=场耦合效应（公理M，2026-10-08 拍板）：构型决定质量
  - 单源磁自能线性叠加=范畴错误（decision#10 作废）
  - 朗之万模型（meetings#57）：单源真空弱锁定 m≈0，集体锁定→938MeV
  - 用户本轮精化：m 随波源间距涌现，分开→m→0
  → 模型变量：m 不是常数，是 x 的函数 m(x)=E_coup(x)/c²
""")

print("="*78)
print("1. 符号推导：m(x) 与 k(x) 同源（非独立参数）")
print("="*78)
x = sp.symbols('x', positive=True)
d_sym, c_sym, E0 = sp.symbols('d c E0', positive=True)
E_coup = E0*sp.exp(-x/d_sym)                    # 场耦合能：指数衰减（波源场特征）
m_x    = sp.simplify(E_coup/c_sym**2)           # 质量涌现
k_x    = sp.simplify(sp.diff(E_coup, x, 2))     # 恢复力刚度（场能二阶导）
print(f"  E_coup(x) = E0·e^(−x/d)    （d=波源场衰减尺度 {d_m/fm:.4f} fm）")
print(f"  m(x)      = E_coup/c² = E0·e^(−x/d)/c²   →  x 越大质量越小 ✓")
print(f"  k(x)      = d²E_coup/dx² = E0·e^(−x/d)/d²")
print(f"  ⇒ m 与 k 比例固定：k/m = c²/d² = ω²（固有频率与 E0 无关！）")
print(f"  ω = c/d = {c/d_m:.3e} rad/s = 2πf0（因为 d=c/2f0 → ω=c/d=2πf0）")
print(f"  ⇒ 呼吸频率 ω = c/d = 2πf0，与耦合强度 E0 无关，纯由几何 d 决定 ✓")
print()

print("="*78)
print("2. 振幅公式（涌现框架）")
print("="*78)
# A = F·τ_b·T / √(k(a)·m(a))
# √(km) = E0·e^(-a/d)/(d·c)   （在平衡间距 a）
a_sym = sp.symbols('a', positive=True)
km = sp.simplify(sp.sqrt(k_x.subs(x, a_sym)*m_x.subs(x, a_sym)))
print(f"  √(k·m) 在平衡间距 a 处 = E0·e^(−a/d)/(d·c)")
A_sym = sp.simplify(sp.symbols('F')*sp.symbols('tau_b')*sp.symbols('T')/km)
print(f"  A = F·τ_b·T·d·c·e^(a/d)/E0")
print(f"  → 注意：E0 出现在分母，耦合越强（E0 大）振幅越小 —— 质量涌现自洽")
print()

print("="*78)
print("3. 数值估计（E0 取 meetings#56 中值 50MeV，a=0.42fm）")
print("="*78)
E0 = 50*MeV
a_src = 0.42*fm
for Fp in [30.0, 300.0, 3000.0]:
    A = Fp*tau_b*T*d_m*c*math.exp(a_src/d_m)/E0/fm
    print(f"  F={Fp:6.0f} N → A = {A:.4f} fm（{'超精度' if A>0.00064 else '测不到'}）")
print()

print("="*78)
print("4. 与旧版（m 固定均分 0.1m_p）对比")
print("="*78)
print("""
  旧版：m 固定 = 938MeV/10/c² → 需人工锚定 m、F 两个参数
  新版：m(x)=E_coup(x)/c² 涌现 → 只需锚定 E0 与 F（m 不再独立）
  量级对比（F=300N）：
    旧版 A ≈ 0.0107 fm（m=0.1m_p，无 e^(a/d) 因子）
    新版 A ≈ 0.0512 fm（E0=50MeV, a=0.42fm，含 e^(a/d)=1.567 因子）
  → 同量级（10⁻² fm），结论不变；但新版参数数减少一个，更自洽
""")

print("="*78)
print("5. 审计：m→0 极限与模型边界")
print("="*78)
print("""
  ① m→0（完全无质量）时 A = Δp/√(km) → 0/0 不定式：需要恢复力同时→0 的极限处理，
     实际物理：波源完全分开时 E_coup→0，k→0 且 m→0，系统不再有"振子"，
     呼吸概念失效（不存在可振荡的对象）——这不是发散悖论，是模型域外。
  ② 有界情形（平衡间距附近小振幅）：m 有限（涌现值 E0·e^(-a/d)/c²），
     冲量→速度→振幅推导有效。
  ③ 更严格：小振幅下 k 的线性化成立（振幅 ≪ a=0.42fm 时，A~0.01fm ≪ a ✓）
  ④ 诚实缺口：E_coup(x) 的精确形式未由库内确定（仅知量级与指数衰减方向），
     本版取纯指数；真实形式（#56 扩展源截断偶极）可能改变 e^(a/d) 因子量级，
     但 10⁻²~10⁻¹ fm 量级结论稳健。
""")
